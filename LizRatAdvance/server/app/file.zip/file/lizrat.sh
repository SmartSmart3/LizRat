#!data/data/com.termux/files/usr/bin/bash
clear
cd LizRatAdvance/server
echo '''

           ▒█░░░ ░▀░ ▀▀█ ▒█▀▀█ █▀▀█ ▀▀█▀▀
           ▒█░░░ ▀█▀ ▄▀░ ▒█▄▄▀ █▄▄█ ░░█░░
           ▒█▄▄█ ▀▀▀ ▀▀▀ ▒█░▒█ ▀░░▀ ░░▀░░
             ℂ𝕣𝕖𝕒𝕥𝕖𝕕 👽 𝕓𝕪 𝕃𝕚𝕫𝟘𝕣𝕕(ᴍᴀɴᴏᴊ)
                  ''' | lolcat

node index.js
